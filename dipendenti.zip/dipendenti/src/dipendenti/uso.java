package dipendenti;

public class uso {
dati chest = new dato();

public uso(dati chest) {
if(data.nome.compareTo(dato.nome < dato.nome2))	
	System.out.println("comparazione");
	else
		System.out.println("comparazione");
}

}
