package dipendenti;

public class dati {
 public String nome;
 public String nome2;
 
public String getNome() {
	return nome;
}

public void setNome(String nome) {
	this.nome = "Chester";
}

public String getNome2() {
	return nome2;
}

public void setNome2(String nome2) {
	this.nome2 = "Joe";
}

}
